# MAGMA

**MAGMA** is a Pterodactyl multiegg tailored for your Minecraft server needs. It features an easy server installer and comes fully configured, ensuring a hassle-free experience from start to finish.

## NOTICE

**This project is NOT free to use without permission from the owner(Arkon/me). As mentioned in the [LICENSE](https://github.com/Noz155/magma/main/license). Any use without permission will result in punishment such as corrupting the file which is being used in the said file of which is being used without permission. To prevent this, just ask nicely by contacting me by discord: @axrcon**
